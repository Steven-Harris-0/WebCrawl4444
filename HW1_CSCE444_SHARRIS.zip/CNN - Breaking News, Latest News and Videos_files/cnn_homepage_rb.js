
AdFuel.registry.push([
{
  "rktr_deployed_date": "2017-05-15 13:37:28",
  "rktr_slot_id": "page",
  "rktr_id": "cnn_homepage_rb",
  "gpt_id": "8663477",
  "site": "cnn",
  "root": "CNN",
  "child_directed_treatment": "false",
  "targeting": []
}
,
{
  "rktr_slot_id": "ad_mod_35731bb1e",
  "rktr_ad_id": "CNN/homepage/landing/pushdown",
  "sizes": [[1,1],[1,2]],
  "targeting": [["pos",["bnr_atf_02"]]],
  "responsive":[]
}

]);
