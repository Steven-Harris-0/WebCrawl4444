Krux.ns._default.kxjsonp_3pevents({
  status: 200,
  body: {  }
});