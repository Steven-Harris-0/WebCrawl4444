//<script>
bouncex.state = {"newvid":true,"iol":true,"tn":1509852718,"pvid":1,"rc":false,"mobile":false,"vip":"129.120.178.58","geo":{"country_code":"US","country_code3":"USA","country_name":"United States","region":"TX","city":"Denton","postal_code":"76203","latitude":33.2148,"longitude":-97.1331,"area_code":940,"dma_code":623,"metro_code":623,"continent_code":"NA","zip":"76203","country":"US"}};
bouncex.cookie = {"v":{"completed_signup":false},"sid":1,"fvt":1509852718,"vid":1509852718102078,"ao":0,"lp":"https%3A%2F%2Fwww.cnn.com%2F","as":0,"vpv":1,"d":"d","r":"","cvt":1509852718,"gcr":67,"m":0,"did":"2036282630427372803","lvt":1509852718};
bouncex.brandStyles = false;
bouncex.webfonts = false;
bouncex.campaigns = false;
bouncex.gbi.stacks = false;
bouncex.debug = false;


bouncex.tryCatch(function(){
	if(bouncex.browser.msie){
		bouncex.setTimeout2(function(){
			bouncex.init();
		}, 0);
	} else {
		bouncex.init();
	}
})();
