(function(){
  window['optimizely'] = window['optimizely'] || [];
  window['optimizely'].push(['activateGeoDelayedExperiments', {
    'location':{
      'city': "DENTON",
      'continent': "NA",
      'country': "US",
      'region': "TX"
    },
    'ip':"129.120.178.58"
  }]);
})
//
()

;