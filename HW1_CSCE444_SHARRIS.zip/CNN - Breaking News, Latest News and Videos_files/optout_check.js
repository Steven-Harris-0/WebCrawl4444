Krux.ns._default.kxjsonp_optOutCheck({
  status: 200,
  body: { "_kuid_": "Ll7trg6D" }
});